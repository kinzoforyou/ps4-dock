# PS4 Dock (Android)

Launcher PS4 dengan dock liquid glass, billing waktu, dan klaim harian. Hanya landscape, layar penuh.

## Cara build lewat GitHub
1. Buat repository baru di GitHub (boleh private).
2. Upload semua isi folder ini. Pastikan folder `.github/workflows/build-apk.yml` ikut terupload.
3. Buka tab **Actions** lalu pilih workflow **Build APK**. Build berjalan otomatis setiap push ke `main`, atau klik **Run workflow**.
4. Setelah selesai (sekitar 4 sampai 8 menit), buka run-nya lalu unduh artifact **PS4-Dock-APK**. Isinya `app-debug.apk`.
5. Pindahkan APK ke HP lalu install (izinkan install dari sumber tidak dikenal).

## Struktur
- `www/index.html`   : aplikasi utama (dock, Home, Settings, billing, klaim harian)
- `www/ps4/`         : PS4 Launcher (sudah ditambah tombol Minimize to Home dan pause input)
- `android-patch/`   : pengaturan layar penuh dan layar tetap menyala
- `icons/`           : ikon aplikasi
- `.github/workflows/build-apk.yml` : build otomatis APK

## Catatan
- Tombol Back di Android: dari PS4 atau Settings kembali ke Home, dari Home meminimalkan aplikasi.
- Billing dan klaim harian disimpan di perangkat (bukan server).
